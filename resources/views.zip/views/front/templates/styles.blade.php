<!-- CSS here -->
<link rel="stylesheet" href=" assets/css/bootstrap.min.css  ">
<link rel="stylesheet" href=" assets/css/owl.carousel.min.css  ">
<link rel="stylesheet" href=" assets/css/flaticon.css  ">
<link rel="stylesheet" href=" assets/css/price_rangs.css  ">
<link rel="stylesheet" href=" assets/css/slicknav.css  ">
<link rel="stylesheet" href=" assets/css/animate.min.css  ">
<link rel="stylesheet" href=" assets/css/magnific-popup.css  ">
<link rel="stylesheet" href=" assets/css/fontawesome-all.min.css  ">
<link rel="stylesheet" href=" assets/css/themify-icons.css  ">
<link rel="stylesheet" href=" assets/css/slick.css  ">
<link rel="stylesheet" href=" assets/css/nice-select.css  ">
<link rel="stylesheet" href=" assets/css/style.css  ">

@stack('styles')